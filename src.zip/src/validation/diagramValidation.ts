// src/validation/diagramValidation.ts

export type Severity = "error" | "warning";

export interface DiagramIssue {
    kind: Severity;
    message: string;
}

const normalize = ( s: string ): string =>
    ( s ?? "" )
        .trim()
        .replace( /\s+/g, " " )
        .toLowerCase();

/**
 * Validate the current editor graph state (App 1).
 * This mirrors UITDL semantic rules at graph level, plus editor-only checks.
 *
 * Expected shape (minimal):
 *  - state.nodes: [{ id, displayId, title, color? }]
 *  - state.edges: [{ from, to, verb, complement, condition? }]
 *  - state.actions: [{ id, ownerDisplayId, verb, complement, targets?: string[] }]
 */
export function validateDiagram( state: any ): DiagramIssue[] {
    const issues: DiagramIssue[] = [];

    const nodes = state?.nodes ?? [];
    const edges = state?.edges ?? [];
    const actions = state?.actions ?? [];

    const error = ( message: string ) => issues.push( { kind: "error", message } );
    const warn = ( message: string ) => issues.push( { kind: "warning", message } );

    // --- Index nodes by displayId ---
    const byDisplayId = new Map<string, any[]>();
    for ( const n of nodes ) {
        const did = String( n.displayId ?? "" );
        if ( !byDisplayId.has( did ) ) byDisplayId.set( did, [] );
        byDisplayId.get( did )!.push( n );

        // editor-only: whitespace in displayId
        if ( /\s/.test( did ) ) {
            error( `displayId '${did}' contains whitespace. displayId must not contain spaces.` );
        }
    }

    // --- Duplicate titles across different displayIds (normalized, case-insensitive) ---
    const titleToDid = new Map<string, string>();
    for ( const [ did, group ] of byDisplayId.entries() ) {
        const title = group[ 0 ]?.title ?? "";
        const norm = normalize( title );
        if ( !norm ) continue;

        const prevDid = titleToDid.get( norm );
        if ( prevDid && prevDid !== did ) {
            error(
                `Duplicate UI title '${title}' used by different displayIds ('${prevDid}' and '${did}'). ` +
                `Titles must be unique (case-insensitive, normalized).`
            );
        } else if ( !prevDid ) {
            titleToDid.set( norm, did );
        }
    }

    // --- UI never used as FROM (error) ---
    const usedFrom = new Set<string>();
    for ( const e of edges ) {
        if ( e?.from != null ) usedFrom.add( String( e.from ) );
    }

    for ( const did of byDisplayId.keys() ) {
        if ( !usedFrom.has( did ) ) {
            error( `UI '${did}' is never used as a transition origin (no outgoing transitions).` );
        }
    }

    // --- Unused actions (error): action with no target/conditions ---
    // In editor terms: actions without targets or edges bound to them.
    for ( const a of actions ) {
        const hasTargets =
            Array.isArray( a.targets ) ? a.targets.length > 0 : false;
        const hasCond =
            a.condition != null && String( a.condition ).trim().length > 0;

        if ( !hasTargets && !hasCond ) {
            error(
                `Action ${a.verb} "${a.complement}" in UI '${a.ownerDisplayId}' has no target or condition.`
            );
        }
    }

    // --- Duplicate transitions (error) ---
    const seen = new Set<string>();
    for ( const e of edges ) {
        const sig = [
            String( e.from ),
            String( e.to ),
            String( e.verb ),
            String( e.complement ),
            normalize( e.condition ?? "" )
        ].join( "|" );

        if ( seen.has( sig ) ) {
            error(
                `Duplicate transition from '${e.from}' to '${e.to}' with action ${e.verb} "${e.complement}".`
            );
        } else {
            seen.add( sig );
        }
    }

    // --- Editor-only: color collisions (warning) ---
    const colorMap = new Map<string, string>();
    for ( const [ did, group ] of byDisplayId.entries() ) {
        const color = group[ 0 ]?.color;
        if ( !color ) continue;
        const prevDid = colorMap.get( color );
        if ( prevDid && prevDid !== did ) {
            warn(
                `Color collision: UIs '${prevDid}' and '${did}' share the same color.`
            );
        } else if ( !prevDid ) {
            colorMap.set( color, did );
        }
    }

    return issues;
}
