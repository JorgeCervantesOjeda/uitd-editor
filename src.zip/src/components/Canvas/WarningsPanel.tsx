// src/components/Canvas/WarningsPanel.tsx
import React, { useMemo } from "react";
import { validateDiagram, DiagramIssue } from "../../validation/diagramValidation";

interface Props {
    appState: any;
}

const kindColor = ( k: "error" | "warning" ) =>
    k === "error" ? "#ff6b6b" : "#f4c430";

export const WarningsPanel: React.FC<Props> = ( { appState } ) => {
    const issues: DiagramIssue[] = useMemo( () => {
        try {
            return validateDiagram( appState );
        } catch ( e: any ) {
            return [
                {
                    kind: "error",
                    message: `Validator crashed: ${e?.message ?? String( e )}`,
                },
            ];
        }
    }, [ appState ] );

    if ( !issues || issues.length === 0 ) return null;

    const errors = issues.filter( ( i ) => i.kind === "error" );
    const warnings = issues.filter( ( i ) => i.kind === "warning" );

    return (
        <div
            style={ {
                position: "absolute",
                right: 12,
                top: 12,
                width: 360,
                maxHeight: "70vh",
                overflowY: "auto",
                background: "#1e1e1e",
                color: "#eee",
                borderRadius: 6,
                boxShadow: "0 4px 16px rgba(0,0,0,0.4)",
                fontSize: 12,
                zIndex: 50,
            } }
        >
            <div
                style={ {
                    padding: "8px 10px",
                    borderBottom: "1px solid #333",
                    fontWeight: 600,
                } }
            >
                Diagnostics
            </div>

            <div style={ { padding: "6px 10px" } }>
                { errors.length > 0 && (
                    <div style={ { marginBottom: 8 } }>
                        <div style={ { color: kindColor( "error" ), fontWeight: 600 } }>
                            Errors ({ errors.length })
                        </div>
                        { errors.map( ( e, i ) => (
                            <div
                                key={ `err-${i}` }
                                style={ {
                                    marginLeft: 8,
                                    marginTop: 4,
                                    color: kindColor( "error" ),
                                } }
                            >
                                • { e.message }
                            </div>
                        ) ) }
                    </div>
                ) }

                { warnings.length > 0 && (
                    <div>
                        <div style={ { color: kindColor( "warning" ), fontWeight: 600 } }>
                            Warnings ({ warnings.length })
                        </div>
                        { warnings.map( ( w, i ) => (
                            <div
                                key={ `warn-${i}` }
                                style={ {
                                    marginLeft: 8,
                                    marginTop: 4,
                                    color: kindColor( "warning" ),
                                } }
                            >
                                • { w.message }
                            </div>
                        ) ) }
                    </div>
                ) }
            </div>
        </div>
    );
};

export default WarningsPanel;
