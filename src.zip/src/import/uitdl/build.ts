// src/import/uitdl/build.ts
import type {
    UITDLDoc,
    UiBlock,
    UiRef,
    FragmentAST,
    TransitionAST,
} from "./types";
import type { AppState } from "../../state/types";

/**
 * Build editor project (graph) from a validated UITDL AST.
 *
 * IMPORTANT:
 * - This builder assumes semantic validation has already run.
 * - It will NOT invent actions from transitions.
 * - All actions must come from UI actions { ... } blocks.
 */

type InstanceKey = string;

const instanceKeyForRef = ( ref: UiRef, parent?: string ): InstanceKey => {
    const cur = parent ? `${parent}(${ref.key})` : `${ref.key}`;
    let out = cur;
    for ( const ch of ref.children ?? [] ) {
        out = instanceKeyForRef( ch, out );
    }
    return out;
};

const collectInstanceKeysFromDraw = (
    ref: UiRef,
    parent?: string
): InstanceKey[] => {
    const thisInst = instanceKeyForRef( ref, parent );
    const keys: InstanceKey[] = [ thisInst ];
    for ( const ch of ref.children ?? [] ) {
        keys.push( ...collectInstanceKeysFromDraw( ch, thisInst ) );
    }
    return keys;
};

const innermostKey = ( r: UiRef ): string => {
    let cur: UiRef = r;
    while ( cur.children && cur.children.length > 0 ) {
        cur = cur.children[ cur.children.length - 1 ];
    }
    return cur.key;
};

export function buildProjectFromAST( ast: UITDLDoc, base: AppState ): AppState {
    const nodes: any[] = [];
    const actions: any[] = [];
    const edges: any[] = [];
    const conditions: any[] = [];

    const uiById = new Map<string, UiBlock>();
    for ( const ui of ast.uiBlocks ) uiById.set( ui.key, ui );

    // --- Build nodes from all DRAW instances across fragments ---
    const seenInstances = new Set<InstanceKey>();

    for ( const fr of ast.fragments ) {
        for ( const r of fr.draw ?? [] ) {
            const insts = collectInstanceKeysFromDraw( r );
            for ( const k of insts ) {
                if ( seenInstances.has( k ) ) continue;
                seenInstances.add( k );

                // innermost UI determines displayId/title
                const parts = k.split( "(" );
                const innermost = parts[ parts.length - 1 ].replace( ")", "" );
                const ui = uiById.get( innermost );

                if ( !ui ) continue; // should not happen after validation

                nodes.push( {
                    id: k,
                    displayId: ui.key,
                    title: ui.name,
                } );
            }
        }
    }

    // --- Build actions only from UI declarations ---
    for ( const ui of ast.uiBlocks ) {
        for ( const a of ui.actions ) {
            actions.push( {
                id: `${ui.key}::${a.verb}::${a.complement}`,
                ownerDisplayId: ui.key,
                verb: a.verb,
                complement: a.complement,
                targets: [],
            } );
        }
    }

    const actionIndex = new Map<string, any>();
    for ( const a of actions ) {
        actionIndex.set(
            `${a.ownerDisplayId}::${a.verb}::${a.complement}`,
            a
        );
    }

    // --- Build edges from transitions ---
    for ( const fr of ast.fragments ) {
        const fragWidth = fr.widthDefault;

        for ( const tr of fr.transitions ?? [] ) {
            const fromInst = instanceKeyForRef( tr.from );
            const toInst = instanceKeyForRef( tr.to );

            const fromId = innermostKey( tr.from );
            const toId = innermostKey( tr.to );

            const actionKey = `${fromId}::${tr.verb}::${tr.complement}`;
            const act = actionIndex.get( actionKey );

            if ( !act ) {
                // Should never happen after validateUITDLDoc
                console.warn(
                    `Skipping transition from '${fromInst}' because action ${tr.verb} "${tr.complement}" is not declared in UI ${fromId}.`
                );
                continue;
            }

            const edgeId = `${fromInst}->${toInst}::${tr.verb}::${tr.complement}`;

            edges.push( {
                id: edgeId,
                from: fromId,
                to: toId,
                fromInst,
                toInst,
                verb: tr.verb,
                complement: tr.complement,
                condition: tr.condLabel ?? "",
                width:
                    tr.width != null
                        ? tr.width
                        : fragWidth != null
                            ? fragWidth
                            : base?.settings?.defaultWrap ?? undefined,
            } );

            // register target in action (editor uses this)
            if ( Array.isArray( act.targets ) ) {
                act.targets.push( toId );
            }
        }
    }

    return {
        ...base,
        nodes,
        actions,
        edges,
        conditions,
    };
}
