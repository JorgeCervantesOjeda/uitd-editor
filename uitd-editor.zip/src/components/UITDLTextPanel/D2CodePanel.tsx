// src/components/UITDLTextPanel/D2CodePanel.tsx
// Provides an editable and downloadable D2 artifact derived from valid UITDL.

import Editor from "@monaco-editor/react";
import {
    useCallback,
    useEffect,
    useLayoutEffect,
    useMemo,
    useRef,
    useState,
    type PointerEvent as ReactPointerEvent,
} from "react";
import { useAppStore } from "../../state/store";
import { useDialogFocusTrap } from "../Canvas/useDialogFocusTrap";
import { ZoomSlider } from "../ZoomSlider";
import { copyText } from "./textClipboard";
import { renderD2, type D2Layout } from "./renderD2";
import { translateUITDLToD2 } from "./uitdlToD2";

type Props = {
    text: string;
    theme: "light" | "dark";
    onClose: () => void;
};

type Status = {
    kind: "info" | "success" | "error";
    message: string;
};

type DiagramDimensions = {
    width: number;
    height: number;
};

type Camera = {
    x: number;
    y: number;
    zoomPercent: number;
};

const MIN_ZOOM_PERCENT = 25;
const MAX_ZOOM_PERCENT = 1200;
const FIT_TO_WIDTH_ZOOM_PERCENT = 100;

type D2ScrollMetrics = {
    maxOffset: number;
    offset: number;
};
const FIT_TO_WIDTH_CAMERA: Camera = { x: 0, y: 0, zoomPercent: FIT_TO_WIDTH_ZOOM_PERCENT };

function percentOfClampedZoom( zoomPercent: number ): number {
    return Math.min( MAX_ZOOM_PERCENT, Math.max( MIN_ZOOM_PERCENT, zoomPercent ) );
}

function percentOfWheelZoom( currentPercent: number, deltaY: number ): number {
    if ( deltaY === 0 ) return currentPercent;
    const factor = deltaY < 0 ? 1.1 : 0.9;
    return percentOfClampedZoom( currentPercent * factor );
}

function dimensionsOfSVGViewBox( svg: string ): DiagramDimensions {
    const documentOfSVG = new DOMParser().parseFromString( svg, "image/svg+xml" );
    const svgElement = documentOfSVG.documentElement;
    const viewBoxParts = ( svgElement.getAttribute( "viewBox" ) ?? "" )
        .trim()
        .split( /[\s,]+/ )
        .map( Number );
    const width = viewBoxParts[ 2 ];
    const height = viewBoxParts[ 3 ];
    if ( viewBoxParts.length === 4 && Number.isFinite( width ) && width > 0 && Number.isFinite( height ) && height > 0 ) {
        return { width, height };
    }
    console.warn( "[D2 render] SVG viewBox dimensions are unavailable.", {
        cause: "The rendered SVG has no positive four-value viewBox.",
        fallback: "Use a square base size for fit-to-width zoom.",
        impact: "The initial diagram aspect ratio may not match the rendered D2 layout.",
    } );
    return { width: 1, height: 1 };
}

function downloadD2( text: string ) {
    const url = URL.createObjectURL( new Blob( [ text ], { type: "text/plain;charset=utf-8" } ) );
    const anchor = document.createElement( "a" );
    anchor.href = url;
    anchor.download = "diagram.d2";
    document.body.appendChild( anchor );
    anchor.click();
    anchor.remove();
    URL.revokeObjectURL( url );
}

function downloadSVG( svg: string ) {
    const url = URL.createObjectURL( new Blob( [ svg ], { type: "image/svg+xml;charset=utf-8" } ) );
    const anchor = document.createElement( "a" );
    anchor.href = url;
    anchor.download = "diagram.d2.svg";
    document.body.appendChild( anchor );
    anchor.click();
    anchor.remove();
    URL.revokeObjectURL( url );
}

function waitForVisibleFeedback(): Promise<void> {
    return new Promise( resolve => {
        window.requestAnimationFrame( () => {
            window.requestAnimationFrame( () => resolve() );
        } );
    } );
}

export function D2CodePanel( { text, theme, onClose }: Props ) {
    const nodes = useAppStore( state => state.nodes );
    const colorsByUIID = useMemo( () => new Map(
        nodes
            .map( node => [
                ( node.displayId ?? "" ).trim(),
                {
                    fill: node.colorFill ?? "#f1f5f9",
                    stroke: node.colorStroke ?? "#94a3b8",
                    text: node.colorText ?? "#334155",
                },
            ] as const )
            .filter( ( [ uiid ] ) => uiid.length > 0 )
    ), [ nodes ] );
    const generatedD2 = useMemo(
        () => translateUITDLToD2( text, { colorsByUIID } ),
        [ colorsByUIID, text ]
    );
    const [ d2Text, setD2Text ] = useState( generatedD2 );
    const [ status, setStatus ] = useState<Status | null>( null );
    const [ layout, setLayout ] = useState<D2Layout>( "elk" );
    const [ svg, setSVG ] = useState( "" );
    const [ diagramDimensions, setDiagramDimensions ] = useState<DiagramDimensions>( { width: 1, height: 1 } );
    const [ isRendering, setIsRendering ] = useState( false );
    const [ isMaximized, setIsMaximized ] = useState( false );
    const [ camera, setCamera ] = useState<Camera>( FIT_TO_WIDTH_CAMERA );
    const [ verticalScroll, setVerticalScroll ] = useState<D2ScrollMetrics>( {
        maxOffset: 0,
        offset: 0,
    } );
    const [ horizontalScroll, setHorizontalScroll ] = useState<D2ScrollMetrics>( {
        maxOffset: 0,
        offset: 0,
    } );
    const [ isPanReady, setIsPanReady ] = useState( false );
    const dialogRef = useRef<HTMLElement | null>( null );
    const viewportRef = useRef<HTMLDivElement | null>( null );
    const diagramRef = useRef<HTMLDivElement | null>( null );
    const cameraRef = useRef( camera );
    const renderedCameraRef = useRef( camera );
    const panRef = useRef<{
        pointerId: number;
        clientX: number;
        clientY: number;
        panX: number;
        panY: number;
    } | null>( null );
    const [ isPanning, setIsPanning ] = useState( false );
    useDialogFocusTrap( true, dialogRef, { onEscape: onClose } );

    const applyCamera = useCallback( ( nextCamera: Camera ) => {
        cameraRef.current = nextCamera;
        setCamera( nextCamera );
    }, [] );

    const refreshDiagramScroll = useCallback( () => {
        const viewport = viewportRef.current;
        const diagram = diagramRef.current;
        if ( !viewport || !diagram ) {
            setVerticalScroll( { maxOffset: 0, offset: 0 } );
            setHorizontalScroll( { maxOffset: 0, offset: 0 } );
            return;
        }

        const viewportStyle = window.getComputedStyle( viewport );
        const paddingTop = Number.parseFloat( viewportStyle.paddingTop ) || 0;
        const paddingRight = Number.parseFloat( viewportStyle.paddingRight ) || 0;
        const paddingBottom = Number.parseFloat( viewportStyle.paddingBottom ) || 0;
        const paddingLeft = Number.parseFloat( viewportStyle.paddingLeft ) || 0;
        const availableHeight = Math.max( 0, viewport.clientHeight - paddingTop - paddingBottom );
        const availableWidth = Math.max( 0, viewport.clientWidth - paddingLeft - paddingRight );
        const scale = cameraRef.current.zoomPercent / 100;
        const scaledDiagramHeight = diagram.offsetHeight * scale;
        const scaledDiagramWidth = diagram.offsetWidth * scale;
        const maxVerticalOffset = Math.max( 0, scaledDiagramHeight - availableHeight );
        const maxHorizontalOffset = Math.max( 0, scaledDiagramWidth - availableWidth );
        const verticalOffset = Math.min( maxVerticalOffset, Math.max( 0, -cameraRef.current.y ) );
        const horizontalOffset = Math.min( maxHorizontalOffset, Math.max( 0, -cameraRef.current.x ) );
        setVerticalScroll( { maxOffset: maxVerticalOffset, offset: verticalOffset } );
        setHorizontalScroll( { maxOffset: maxHorizontalOffset, offset: horizontalOffset } );
    }, [] );

    const resetToFitWidth = useCallback( () => {
        const viewport = viewportRef.current;
        if ( viewport ) {
            viewport.scrollLeft = 0;
            viewport.scrollTop = 0;
        }
        applyCamera( FIT_TO_WIDTH_CAMERA );
    }, [ applyCamera ] );

    useLayoutEffect( () => {
        renderedCameraRef.current = camera;
    }, [ camera ] );

    const applyAnchoredZoom = useCallback( ( nextZoomPercent: number, clientX: number, clientY: number ) => {
        const diagram = diagramRef.current;
        if ( !diagram ) return;
        const currentCamera = cameraRef.current;
        const nextPercent = percentOfClampedZoom( nextZoomPercent );
        if ( nextPercent === FIT_TO_WIDTH_ZOOM_PERCENT ) {
            resetToFitWidth();
            return;
        }
        if ( nextPercent === currentCamera.zoomPercent ) return;
        const diagramBounds = diagram.getBoundingClientRect();
        const renderedCamera = renderedCameraRef.current;
        const diagramBaseLeft = diagramBounds.left - renderedCamera.x;
        const diagramBaseTop = diagramBounds.top - renderedCamera.y;
        const currentScale = currentCamera.zoomPercent / 100;
        const nextScale = nextPercent / 100;
        const anchorX = ( clientX - diagramBaseLeft - currentCamera.x ) / currentScale;
        const anchorY = ( clientY - diagramBaseTop - currentCamera.y ) / currentScale;
        applyCamera( {
            x: currentCamera.x + ( currentScale - nextScale ) * anchorX,
            y: currentCamera.y + ( currentScale - nextScale ) * anchorY,
            zoomPercent: nextPercent,
        } );
    }, [ applyCamera, resetToFitWidth ] );

    useEffect( () => {
        const keyDown = ( event: KeyboardEvent ) => {
            if ( event.key === "Control" || event.key === "Meta" ) setIsPanReady( true );
        };
        const keyUp = ( event: KeyboardEvent ) => setIsPanReady( event.ctrlKey || event.metaKey );
        const clearPanReady = () => setIsPanReady( false );
        window.addEventListener( "keydown", keyDown );
        window.addEventListener( "keyup", keyUp );
        window.addEventListener( "blur", clearPanReady );
        return () => {
            window.removeEventListener( "keydown", keyDown );
            window.removeEventListener( "keyup", keyUp );
            window.removeEventListener( "blur", clearPanReady );
        };
    }, [] );

    useLayoutEffect( () => {
        const viewport = viewportRef.current;
        const diagram = diagramRef.current;
        if ( !viewport || !diagram || !svg ) return;
        const zoomWithWheel = ( event: WheelEvent ) => {
            event.preventDefault();
            const currentPercent = cameraRef.current.zoomPercent;
            applyAnchoredZoom( percentOfWheelZoom( currentPercent, event.deltaY ), event.clientX, event.clientY );
        };
        viewport.addEventListener( "wheel", zoomWithWheel, { passive: false } );
        return () => viewport.removeEventListener( "wheel", zoomWithWheel );
    }, [ applyAnchoredZoom, svg ] );

    useLayoutEffect( () => {
        if ( !svg ) return;
        resetToFitWidth();
    }, [ diagramDimensions, resetToFitWidth, svg ] );

    useLayoutEffect( () => {
        if ( !svg || cameraRef.current.zoomPercent !== FIT_TO_WIDTH_ZOOM_PERCENT ) return;
        resetToFitWidth();
    }, [ isMaximized, resetToFitWidth, svg ] );

    useLayoutEffect( () => {
        const frame = window.requestAnimationFrame( refreshDiagramScroll );
        return () => window.cancelAnimationFrame( frame );
    }, [ camera, diagramDimensions, isMaximized, refreshDiagramScroll, svg ] );

    useLayoutEffect( () => {
        const viewport = viewportRef.current;
        const diagram = diagramRef.current;
        if ( !viewport || !diagram || !svg || typeof ResizeObserver === "undefined" ) return;

        let frame = 0;
        const observer = new ResizeObserver( () => {
            window.cancelAnimationFrame( frame );
            frame = window.requestAnimationFrame( refreshDiagramScroll );
        } );
        observer.observe( viewport );
        observer.observe( diagram );

        return () => {
            observer.disconnect();
            window.cancelAnimationFrame( frame );
        };
    }, [ refreshDiagramScroll, svg ] );

    const setHorizontalScrollOffset = ( nextOffset: number ) => {
        const maxOffset = horizontalScroll.maxOffset;
        const clampedOffset = Math.min( maxOffset, Math.max( 0, nextOffset ) );
        applyCamera( {
            ...cameraRef.current,
            x: -clampedOffset,
        } );
    };

    const setVerticalScrollOffset = ( nextOffset: number ) => {
        const maxOffset = verticalScroll.maxOffset;
        const clampedOffset = Math.min( maxOffset, Math.max( 0, nextOffset ) );
        applyCamera( {
            ...cameraRef.current,
            y: -clampedOffset,
        } );
    };

    const setZoomFromSlider = ( zoomPercent: number ) => {
        const viewport = viewportRef.current;
        if ( !viewport ) return;
        const bounds = viewport.getBoundingClientRect();
        applyAnchoredZoom( zoomPercent, bounds.left + bounds.width / 2, bounds.top + bounds.height / 2 );
    };

    const copyD2 = async () => {
        setStatus( { kind: "info", message: "Copying D2 source…" } );
        try {
            await copyText( d2Text );
            setStatus( { kind: "success", message: "D2 source copied." } );
        } catch ( error ) {
            console.error( "[D2 source] Copy failed after all clipboard methods.", error );
            setStatus( { kind: "error", message: "Could not copy D2 source." } );
        }
    };

    const renderDiagram = async () => {
        if ( isRendering || !d2Text.trim() ) return;
        setIsRendering( true );
        setStatus( { kind: "info", message: `Rendering D2 with ${layout.toUpperCase()}…` } );
        await waitForVisibleFeedback();
        try {
            const renderedSVG = await renderD2( d2Text, layout );
            setDiagramDimensions( dimensionsOfSVGViewBox( renderedSVG ) );
            setSVG( renderedSVG );
            setStatus( { kind: "success", message: `D2 rendered with ${layout.toUpperCase()}.` } );
        } catch ( error ) {
            console.error( "[D2 render] Compilation or rendering failed.", {
                cause: error,
                layout,
                fallback: "Keep the last successful SVG, if one exists.",
                impact: "The current D2 source is not displayed.",
            } );
            setStatus( {
                kind: "error",
                message: error instanceof Error ? error.message : "D2 could not compile the current source.",
            } );
        } finally {
            setIsRendering( false );
        }
    };

    const startPan = ( event: ReactPointerEvent<HTMLDivElement> ) => {
        const isMiddleButton = event.button === 1;
        const isModifiedLeftButton = event.button === 0 && ( event.ctrlKey || event.metaKey );
        if ( ( !isMiddleButton && !isModifiedLeftButton ) || !svg ) return;
        const viewport = event.currentTarget;
        event.preventDefault();
        viewport.setPointerCapture( event.pointerId );
        panRef.current = {
            pointerId: event.pointerId,
            clientX: event.clientX,
            clientY: event.clientY,
            panX: cameraRef.current.x,
            panY: cameraRef.current.y,
        };
        setIsPanning( true );
    };

    const panDiagram = ( event: ReactPointerEvent<HTMLDivElement> ) => {
        const pan = panRef.current;
        if ( !pan || pan.pointerId !== event.pointerId ) return;
        applyCamera( {
            ...cameraRef.current,
            x: pan.panX + event.clientX - pan.clientX,
            y: pan.panY + event.clientY - pan.clientY,
        } );
    };

    const stopPan = ( event: ReactPointerEvent<HTMLDivElement> ) => {
        const pan = panRef.current;
        if ( !pan || pan.pointerId !== event.pointerId ) return;
        if ( event.currentTarget.hasPointerCapture( event.pointerId ) ) {
            event.currentTarget.releasePointerCapture( event.pointerId );
        }
        panRef.current = null;
        setIsPanning( false );
    };

    return (
        <div
            className={ `d2CodePanel__backdrop${isMaximized ? " is-maximized" : ""}` }
            role="presentation"
        >
            <section
                ref={ dialogRef }
                className={ `d2CodePanel${isMaximized ? " is-maximized" : ""}` }
                role="dialog"
                aria-modal="true"
                aria-label="D2 source editor"
                tabIndex={ -1 }
            >
                <header className="d2CodePanel__header">
                    <div>
                        <strong>D2 source</strong>
                        <span>Derived presentation artifact; edits do not change UITDL.</span>
                    </div>
                    <div className="d2CodePanel__windowActions">
                        <button
                            type="button"
                            onClick={ () => setIsMaximized( current => !current ) }
                            aria-label={ isMaximized ? "Restore D2 window" : "Maximize D2 window" }
                            aria-pressed={ isMaximized }
                        >
                            { isMaximized ? "Restore" : "Maximize" }
                        </button>
                        <button type="button" onClick={ onClose } aria-label="Close D2 source editor">×</button>
                    </div>
                </header>
                <div className="d2CodePanel__actions">
                    <label htmlFor="d2-layout">Layout</label>
                    <select
                        id="d2-layout"
                        value={ layout }
                        onChange={ event => setLayout( event.target.value as D2Layout ) }
                        disabled={ isRendering }
                    >
                        <option value="elk">ELK</option>
                        <option value="dagre">Dagre</option>
                    </select>
                    <button type="button" onClick={ renderDiagram } disabled={ isRendering || !d2Text.trim() }>
                        { isRendering ? "Rendering…" : "Render diagram" }
                    </button>
                    <button type="button" onClick={ () => {
                        setStatus( { kind: "info", message: "D2 source regenerated from UITDL." } );
                        setD2Text( generatedD2 );
                    } } disabled={ isRendering }>
                        Regenerate
                    </button>
                    <button type="button" onClick={ copyD2 } disabled={ isRendering }>Copy D2</button>
                    <button type="button" onClick={ () => {
                        setStatus( { kind: "info", message: "Preparing diagram.d2…" } );
                        downloadD2( d2Text );
                        setStatus( { kind: "success", message: "diagram.d2 downloaded." } );
                    } } disabled={ isRendering }>
                        Download .d2
                    </button>
                    <button type="button" onClick={ () => downloadSVG( svg ) } disabled={ isRendering || !svg }>
                        Download SVG
                    </button>
                </div>
                { status && (
                    <div className={ `d2CodePanel__status is-${status.kind}` } role="status">
                        <span>{ status.message }</span>
                        <button type="button" onClick={ () => setStatus( null ) } aria-label="Dismiss D2 status">×</button>
                    </div>
                ) }
                <div className="d2CodePanel__workspace">
                    <div className="d2CodePanel__editor">
                        <Editor
                            defaultLanguage="plaintext"
                            theme={ theme === "dark" ? "vs-dark" : "vs" }
                            value={ d2Text }
                            onChange={ value => setD2Text( value ?? "" ) }
                            loading="Loading D2 editor…"
                            options={ {
                                automaticLayout: true,
                                minimap: { enabled: false },
                                fontSize: 14,
                                wordWrap: "off",
                                scrollBeyondLastLine: false,
                            } }
                        />
                    </div>
                    <div className="d2CodePanel__preview" aria-label="Rendered D2 diagram">
                        <div
                            ref={ viewportRef }
                            className={ `d2CodePanel__viewport${isPanReady ? " is-grab-ready" : ""}${isPanning ? " is-panning" : ""}` }
                            aria-label="D2 pan and zoom viewport"
                            onPointerDown={ startPan }
                            onPointerMove={ panDiagram }
                            onPointerUp={ stopPan }
                            onPointerCancel={ stopPan }
                        >
                            { svg ? (
                                <div
                                    ref={ diagramRef }
                                    className="d2CodePanel__svg"
                                    role="img"
                                    aria-label={ `D2 diagram rendered with ${layout.toUpperCase()}` }
                                    style={ {
                                        aspectRatio: `${diagramDimensions.width} / ${diagramDimensions.height}`,
                                        transform: `translate(${camera.x}px, ${camera.y}px) scale(${camera.zoomPercent / 100})`,
                                    } }
                                    dangerouslySetInnerHTML={ { __html: svg } }
                                />
                            ) : (
                                <p>Choose a layout and render the current D2 source.</p>
                            ) }
                        </div>
                        <input
                            className="diagramHorizontalScrollbar d2HorizontalScrollbar"
                            type="range"
                            min={ 0 }
                            max={ Math.max( 1, horizontalScroll.maxOffset ) }
                            step={ 1 }
                            value={ horizontalScroll.maxOffset > 0 ? horizontalScroll.offset : 0 }
                            disabled={ !svg || horizontalScroll.maxOffset <= 0 }
                            aria-label="Horizontal D2 diagram scroll"
                            aria-valuetext={ horizontalScroll.maxOffset > 0
                                ? `${Math.round( horizontalScroll.offset )} of ${Math.round( horizontalScroll.maxOffset )}`
                                : "Diagram fits horizontally" }
                            onChange={ event => setHorizontalScrollOffset( Number( event.target.value ) ) }
                            onWheel={ event => {
                                event.preventDefault();
                                event.stopPropagation();
                                const pageSize = viewportRef.current?.clientWidth ?? 0;
                                const wheelDelta = Math.abs( event.deltaX ) > Math.abs( event.deltaY )
                                    ? event.deltaX
                                    : event.deltaY;
                                const deltaUnit = event.deltaMode === 1
                                    ? 16
                                    : event.deltaMode === 2
                                        ? pageSize
                                        : 1;
                                setHorizontalScrollOffset( horizontalScroll.offset + wheelDelta * deltaUnit );
                            } }
                        />

                        <input
                            className="diagramVerticalScrollbar d2VerticalScrollbar"
                            type="range"
                            min={ 0 }
                            max={ Math.max( 1, verticalScroll.maxOffset ) }
                            step={ 1 }
                            value={ verticalScroll.maxOffset > 0 ? verticalScroll.offset : 0 }
                            disabled={ !svg || verticalScroll.maxOffset <= 0 }
                            aria-label="Vertical D2 diagram scroll"
                            aria-valuetext={ verticalScroll.maxOffset > 0
                                ? `${Math.round( verticalScroll.offset )} of ${Math.round( verticalScroll.maxOffset )}`
                                : "Diagram fits vertically" }
                            onChange={ event => setVerticalScrollOffset( Number( event.target.value ) ) }
                            onWheel={ event => {
                                event.preventDefault();
                                event.stopPropagation();
                                const pageSize = viewportRef.current?.clientHeight ?? 0;
                                const deltaUnit = event.deltaMode === 1
                                    ? 16
                                    : event.deltaMode === 2
                                        ? pageSize
                                        : 1;
                                setVerticalScrollOffset( verticalScroll.offset + event.deltaY * deltaUnit );
                            } }
                        />
                        <ZoomSlider
                            className="d2ZoomSlider"
                            minPercent={ MIN_ZOOM_PERCENT }
                            maxPercent={ MAX_ZOOM_PERCENT }
                            valuePercent={ camera.zoomPercent }
                            onChange={ setZoomFromSlider }
                            disabled={ !svg }
                        />
                    </div>
                </div>
            </section>
        </div>
    );
}
